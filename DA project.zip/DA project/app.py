import streamlit as st  
import pandas as pd  
import matplotlib.pyplot as plt  
import seaborn as sns  
import plotly.express as px  
import cufflinks as cf
from plotly.offline import init_notebook_mode
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

st.set_page_config(
    page_title="Drug Effectiveness Analysis",
    page_icon="💊",
    layout="centered",
    initial_sidebar_state="expanded"
)

# Initialize Cufflinks and Plotly
cf.go_offline()
init_notebook_mode(connected=True)



# Title and description
st.title("Drug Effectiveness Analysis Dashboard")  
st.write("A showcase of Our data visualizations and insights.")  

st.markdown("""
This web application provides an in-depth analysis and predictive insights into drug ratings based on user reviews. 
Using a dataset comprising various factors such as **Price**, **Ease of Use**, **Effectiveness**, and **Satisfaction**, 
we explore patterns and relationships to understand what drives overall drug ratings.

### Key Features of the Analysis:
- **Univariate Analysis:** Examines the distribution of individual features to detect trends and outliers.
- **Bivariate & Multivariate Analysis:** Explores relationships between features like Price, Satisfaction, and Condition using scatter plots, box plots, and 3D visualizations.
- **Correlation Insights:** A heatmap highlights how different features are correlated, helping in feature selection for modeling.
- **Outlier Detection:** Outliers in features like Price were detected using the IQR method, ensuring a cleaner dataset for model training.

### Prediction Model:
We utilized a **Random Forest Regressor** to predict the overall drug rating, chosen for its ability to handle non-linear relationships and provide robust predictions.

This app empowers users to explore the data interactively and gain insights into the factors influencing drug ratings.
""")


# Upload dataset
st.header("Dataset Preview")
df = pd.read_csv("Drug_clean.csv")  # Replace with your dataset path
st.dataframe(df)



# List of categorical columns
cat_cols = ['Condition', 'Drug', 'Form', 'Indication', 'Type']

# Convert to 'category' dtype
for col in cat_cols:
    df[col] = df[col].astype('category')

# Encode categorical columns using LabelEncoder
encoder = LabelEncoder()
for col in cat_cols:
    df[col] = encoder.fit_transform(df[col])

# Convert numerical columns to float (if not already)
num_cols = ['EaseOfUse', 'Effective', 'Price', 'Reviews', 'Satisfaction']
df[num_cols] = df[num_cols].astype('float64')





# Initialize transformers
scaler = MinMaxScaler()
encoder = LabelEncoder()

# Normalize numerical columns
df[num_cols] = scaler.fit_transform(df[num_cols])

# Encode categorical columns
for col in cat_cols:
    df[col] = encoder.fit_transform(df[col])
    


# Example of Min-Max scaling inverse
original_min = 0  # Replace with the original minimum
original_max = 300  # Replace with the original maximum
df['Price'] = df['Price'] * (original_max - original_min) + original_min

   
    

# Visualization 1
st.header("Univariate Analysis")  
st.subheader("Histograms of Numerical Columns")  

try:
    # Plot histograms for numerical columns
    df[num_cols].hist(bins=20, figsize=(10, 8))
    plt.tight_layout()
    st.pyplot(plt)  # Use st.pyplot to render the plot in Streamlit

    # Insights
    st.subheader("Insights from the Histograms:")

    # Ease of Use Insights
    st.markdown("""
    **Ease of Use:**
    - The distribution of Ease of Use ratings may indicate the general perception of the drug's usability. 
    - If the histogram is right-skewed, most drugs are perceived as easy to use, while a left skew would suggest that ease of use is more varied.
    """)

    # Effectiveness Insights
    st.markdown("""
    **Effectiveness:**
    - The histogram shows how effective users rate the drugs.
    - A left-skewed distribution suggests most drugs are rated as highly effective, while a more even distribution means users have mixed experiences.
    """)

    # Price Insights
    st.markdown("""
    **Price:**
    - The histogram illustrates the distribution of drug prices.
    - A right-skewed distribution would indicate that most drugs are affordable, with a few significantly more expensive.
    - A uniform distribution suggests a more balanced range of prices across drugs.
    """)

    # Reviews Insights
    st.markdown("""
    **Reviews:**
    - This plot shows the number of reviews per drug.
    - A peak at the left (lower review count) suggests that most drugs have fewer reviews, while a more spread-out distribution means certain drugs have many more reviews.
    """)

    # Satisfaction Insights
    st.markdown("""
    **Satisfaction:**
    - The satisfaction histogram reveals how users feel about the drugs.
    - If the histogram is right-skewed, it indicates that most users are satisfied with the drugs, with only a few dissatisfied users.
    - A more even distribution means that users have a variety of opinions regarding the satisfaction of the drugs.
    """)

except Exception as e:
    st.error(f"Error generating histograms: {e}")




# Visualization 2: Histogram
st.header("Detecting Outliers in 'Price'")
st.subheader("Price Distribution (Histogram)")

try:
    # Create a histogram to detect outliers in 'Price'
    fig2 = px.histogram(df, x='Price', nbins=20, title='Price Distribution (Histogram)', 
                        labels={'Price': 'Price (₹)'}, marginal='box')
    st.plotly_chart(fig2)

    # Insights
    st.subheader("Insights from the 'Price' Distribution:")

    st.markdown("""
    **Price Distribution:**
    - The histogram shows how drug prices are distributed in the dataset.
    - A right-skewed distribution would indicate that most drugs are priced lower, while a few drugs are priced significantly higher.
    - If the histogram appears with a heavy concentration on the lower end of the price range, it suggests that most drugs are affordable, and only a few are expensive.
    
    **Box Plot:**
    - The box plot embedded within the histogram helps to detect outliers in the 'Price' distribution.
    - The whiskers of the box plot represent the range of prices within 1.5 times the interquartile range (IQR). Any points outside this range can be considered potential outliers.
    - If there are dots outside the whiskers, these represent outlier prices, which could be extremely high or low compared to the majority of drugs in the dataset.
    - Outliers might indicate rare, specialized, or branded drugs with unusually high prices.
    """)

except Exception as e:
    st.error(f"Error generating the price distribution histogram: {e}")




# Visualization 3: Plot for Satisfaction KDE
st.subheader("Satisfaction Distribution (KDE Plot)")  

try:
    # Create KDE plot for 'Satisfaction' using Plotly
    fig = px.density_contour(df, x='Satisfaction', title='Satisfaction Distribution (KDE Plot)', 
                             labels={'Satisfaction': 'Satisfaction Level'})
    fig.update_traces(contours_coloring="fill", contours_showlabels=True)
    
    # Update axis labels
    fig.update_layout(xaxis_title="Satisfaction Score", yaxis_title="Density")

    # Display plot in Streamlit
    st.plotly_chart(fig)

    # Insights
    st.subheader("Insights from the 'Satisfaction' Distribution:")

    st.markdown("""
    **Satisfaction Distribution:**
    - The KDE (Kernel Density Estimation) plot gives a smoothed curve that represents the distribution of satisfaction scores.
    - It shows how frequently different satisfaction levels occur in the dataset, with areas of higher density representing common satisfaction scores.
    - If the curve is centered at a high value, it indicates that most users are highly satisfied with the drugs.
    - If there are multiple peaks (multimodal), it could suggest different groups of satisfaction levels, such as some users being very satisfied, while others are less satisfied.
    
    **Contours:**
    - The contour lines provide additional insights into the density of satisfaction levels.
    - Higher-density areas are filled with color and represent regions where satisfaction scores are more concentrated.
    - The areas with fewer contour lines indicate lower-density regions, where satisfaction scores are less common.
    """)

except Exception as e:
    st.error(f"Error generating the KDE plot: {e}")




# Visualization 4: Proportions of conditions in dataset
st.subheader("Condition Distribution (Pie Chart)")  

try:
    # Create Pie chart for 'Condition' column
    fig = px.pie(df, names='Condition', title='Condition Distribution')

    # Display plot in Streamlit
    st.plotly_chart(fig)

    # Insights
    st.subheader("Insights from the 'Condition' Distribution:")

    st.markdown("""
    **Condition Distribution:**
    - The pie chart shows the distribution of different conditions present in the dataset.
    - Each slice represents the proportion of records belonging to a particular condition.
    - By observing the size of each slice, you can quickly identify which condition is most common and which are less frequent.
    - If one slice is significantly larger than others, it indicates that a particular condition dominates the dataset.

    **Interpretation:**
    - For example, if the "Acute Bacterial Sinusitis" condition is the largest slice, it means this condition is more prevalent in the dataset compared to others.
    - The relative sizes of the slices can also provide insights into the variety of conditions present, showing whether the dataset is more focused on a few conditions or includes many different conditions equally.
    """)

except Exception as e:
    st.error(f"Error generating pie chart: {e}")



import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Visualization 5: Categorical distribution using donut charts
st.subheader("Categorical Feature Distributions (Donut Charts)")  

try:
    # Create a subplot grid
    fig = make_subplots(
        rows=1, cols=3,  # 1 row, 3 columns
        subplot_titles=('Form Distribution', 'Indication Distribution', 'Type Distribution'),
        specs=[[{'type': 'pie'}, {'type': 'pie'}, {'type': 'pie'}]]  # Use pie charts for each
    )

    # Donut chart for 'Form' column
    form_counts = df['Form'].value_counts()
    form_pie = go.Pie(labels=form_counts.index, values=form_counts.values, hole=0.4, name='Form')
    fig.add_trace(form_pie, row=1, col=1)

    # Donut chart for 'Indication' column
    indication_counts = df['Indication'].value_counts()
    indication_pie = go.Pie(labels=indication_counts.index, values=indication_counts.values, hole=0.4, name='Indication')
    fig.add_trace(indication_pie, row=1, col=2)

    # Donut chart for 'Type' column
    type_counts = df['Type'].value_counts()
    type_pie = go.Pie(labels=type_counts.index, values=type_counts.values, hole=0.4, name='Type')
    fig.add_trace(type_pie, row=1, col=3)

    # Update layout
    fig.update_layout(
        title_text="Categorical Feature Distributions",
        showlegend=True,
        height=600,  # Adjusting figure size
        title_x=0.5  # Centering the title
    )

    # Display plot in Streamlit
    st.plotly_chart(fig)

    # Insights
    st.subheader("Insights from the Categorical Feature Distributions:")

    st.markdown("""
    **Form Distribution (Donut Chart):**
    - The form of a drug (e.g., capsule, cream, tablet, etc.) represents how the drug is administered. 
    - This chart shows the proportions of different forms in the dataset, highlighting the most common forms.
    - If one slice takes up the majority of the pie, it indicates that a specific form of drug is more prevalent in the dataset.

    **Indication Distribution (Donut Chart):**
    - The indication shows whether the drug is used for on-label or off-label purposes.
    - This chart visualizes how frequently each type of indication appears in the dataset.
    - A higher proportion of on-label drugs would suggest that most drugs in the dataset are prescribed for their intended use.

    **Type Distribution (Donut Chart):**
    - This distribution shows the drug type (e.g., prescription (RX)).
    - The chart provides insight into the types of drugs included in the dataset, where the size of the slices indicates how many drugs fall under each type.
    - If most drugs are of the prescription type, this chart will reflect that concentration.
    """)

except Exception as e:
    st.error(f"Error generating donut charts: {e}")




#Bivariate Analysis
# Scatter plot for price vs satisfaction
st.header("Bivariate Analysis")

# Visualization: Price vs Satisfaction (Scatter Plot)
st.subheader("Price vs Satisfaction (Scatter Plot)")  

try:
    # Create Scatter plot for 'Price' vs 'Satisfaction'
    fig = px.scatter(df, x='Price', y='Satisfaction', title='Price vs Satisfaction',
                     labels={'Price': 'Price (₹)', 'Satisfaction': 'Satisfaction Level'})

    # Display plot in Streamlit
    st.plotly_chart(fig)

    # Insights
    st.subheader("Insights from Price vs Satisfaction Plot:")

    st.markdown("""
    - This scatter plot visualizes the relationship between the price of drugs and their satisfaction score.
    - Each point on the plot represents a drug, with its price on the x-axis and satisfaction on the y-axis.
    - A trend or pattern can be observed to see if higher-priced drugs tend to have higher or lower satisfaction scores.
    - If the points are scattered widely without a clear pattern, it may indicate that price does not have a strong correlation with satisfaction.
    - This type of plot helps to identify if expensive drugs are rated better or worse in terms of satisfaction by users.
    """)
    
except Exception as e:
    st.error(f"Error generating scatter plot: {e}")




# Visualization: Correlation Matrix (Heatmap)
st.subheader("Correlation Matrix (Heatmap)")  

try:
    # Calculate correlation matrix
    corr_matrix = df.corr()

    # Create and display heatmap
    plt.figure(figsize=(8, 6))
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=0.5)
    plt.title('Correlation Matrix of Numerical Features')
    st.pyplot(plt)  # Use st.pyplot to render the plot in Streamlit

    # Insights
    st.subheader("Insights from Correlation Matrix:")
    st.markdown("""
    - The correlation matrix helps us understand the linear relationship between the numerical features in the dataset.
    - Values close to 1 indicate a strong positive correlation, while values close to -1 indicate a strong negative correlation.
    - Values around 0 suggest no significant linear relationship between the variables.
    - For example, if the correlation between 'Price' and 'Satisfaction' is close to 1, it would indicate that higher-priced drugs tend to have higher satisfaction scores.
    - In this heatmap, we can quickly identify which variables are strongly related to each other, and which ones show weak or no correlation.
    - The heatmap helps in identifying multicollinearity, which could be useful in further analysis or predictive modeling.
    """)
except Exception as e:
    st.error(f"Error generating correlation heatmap: {e}")




# Visualization: Price Distribution Across Conditions (Box Plot)
st.subheader("Price Distribution Across Conditions (Box Plot)")  

try:
    # Create Box plot for 'Price' distribution across 'Condition'
    fig = px.box(df, x='Condition', y='Price', title='Price Distribution Across Conditions',
                 labels={'Condition': 'Condition', 'Price': 'Price'})

    # Display plot in Streamlit
    st.plotly_chart(fig)

    # Insights
    st.subheader("Insights from Box Plot:")
    st.markdown("""
    - The box plot shows the distribution of 'Price' for each 'Condition' category.
    - The central line within each box represents the median price for each condition, while the boxes show the interquartile range (IQR), meaning the middle 50% of the data.
    - The whiskers show the range of the data outside the IQR, excluding outliers.
    - Outliers are represented as individual points outside the whiskers.
    - Conditions with wider boxes or longer whiskers have a greater price variation, suggesting a wider range of prices for drugs in that condition category.
    - This plot can be helpful in understanding the price distribution for different conditions and identifying if some conditions are associated with higher-priced drugs.
    """)
except Exception as e:
    st.error(f"Error generating box plot: {e}")




# Visualization: Satisfaction Distribution by Form (Violin Plot)
st.subheader("Satisfaction Distribution by Form (Violin Plot)")  

try:
    # Create Violin plot for 'Satisfaction' distribution by 'Form'
    fig = px.violin(df, x='Form', y='Satisfaction', box=True, points="all", 
                    title="Satisfaction Distribution by Form", 
                    labels={'Form': 'Form', 'Satisfaction': 'Satisfaction'})

    # Display plot in Streamlit
    st.plotly_chart(fig)

    # Insights
    st.subheader("Insights from Violin Plot:")
    st.markdown("""
    - The violin plot provides a detailed view of the distribution of 'Satisfaction' scores for each drug 'Form'.
    - The **width of the violin** at different satisfaction levels indicates the density of the data points, showing where most of the satisfaction scores are concentrated.
    - The **box** in the plot shows the interquartile range (IQR), with the median satisfaction score represented by the thick line inside the box.
    - **Points** shown as individual dots represent all the satisfaction scores for each form, which helps in identifying outliers or extreme values.
    - The plot helps us understand the **variation in satisfaction levels** for different drug forms and can highlight if certain forms tend to have higher or lower satisfaction levels.
    - If a form has a wider spread, it indicates more variability in the satisfaction scores for that form.
    """)
except Exception as e:
    st.error(f"Error generating violin plot: {e}")




# Visualization: Pairplot of Numerical Columns
st.subheader("Pairplot of Numerical Columns")

try:
    # Create pairplot for numerical columns
    sns.pairplot(df[num_cols])
    plt.tight_layout()  # Adjust layout for better visualization
    st.pyplot(plt)  # Use st.pyplot to render the plot in Streamlit

    # Insights
    st.subheader("Insights from Pairplot:")
    st.markdown("""
    - The **pairplot** visualizes relationships between all pairs of numerical variables in the dataset.
    - Each **scatter plot** shows how two numerical features relate to each other. The diagonal elements show the **distribution** of each feature individually (histograms or KDEs).
    - **Correlations** can be visually identified by observing the pattern of data points in the scatter plots:
        - If the data points form a clear linear trend (upward or downward), it indicates a **strong correlation** between the features.
        - If the scatter points are more spread out with no clear pattern, the relationship between the features is **weak** or **non-linear**.
    - **Color coding** (if applied) can help highlight patterns or clusters in the data.
    - This plot is useful to identify any strong **linear relationships** between features, detect outliers, and assess if transformations might be needed (e.g., for non-linear relationships).
    """)

except Exception as e:
    st.error(f"Error generating pairplot: {e}")




# Multivariate analysis
st.header("Multivariate Analysis")

# Visualization: Heatmap of Satisfaction by Form
st.subheader("Heatmap of Satisfaction by Form")

try:
    # Group by 'Form' and calculate the average Satisfaction for each 'Form'
    heatmap_data = df.groupby('Form')['Satisfaction'].mean().reset_index()

    # Create the heatmap
    plt.figure(figsize=(8, 6))
    sns.heatmap(heatmap_data.set_index('Form').T, annot=True, cmap="YlGnBu", cbar=True, fmt=".2f")

    # Title for the heatmap
    plt.title("Heatmap of Satisfaction by Form")

    # Display plot in Streamlit
    st.pyplot(plt)

    # Provide insights on the heatmap
    st.write("""
        **Insights:**
        - This heatmap visualizes the **average satisfaction** for each form type (e.g., Cream, Capsule, Tablet).
        - The **darker colors** represent higher satisfaction, while the **lighter colors** indicate lower satisfaction levels.
        - The **annotated values** within each cell display the exact **mean satisfaction score** for that particular form type.
        - By comparing the colors and values, you can easily identify which form types are associated with higher satisfaction levels.
        - This plot helps to understand how **form type** influences **customer satisfaction** in your dataset.
    """)

except Exception as e:
    st.error(f"Error generating heatmap: {e}")




# Visualization: 3D Scatter Plot of Price, Satisfaction, and EaseOfUse
st.subheader("3D Scatter Plot of Price, Satisfaction, and EaseOfUse")

try:
    # Create 3D scatter plot for 'Price', 'Satisfaction', and 'EaseOfUse'
    fig = px.scatter_3d(df, x='Price', y='Satisfaction', z='EaseOfUse', 
                        title='Price, Satisfaction, and EaseOfUse 3D Scatter Plot')

    # Display plot in Streamlit
    st.plotly_chart(fig)

    # Provide insights on the plot
    st.write("""
        **Insights:**
        - This **3D scatter plot** visualizes the relationship between **Price**, **Satisfaction**, and **Ease of Use**.
        - The **x-axis** represents the **Price** of the drug, the **y-axis** represents **Satisfaction**, and the **z-axis** represents the **Ease of Use**.
        - The distribution of points in the plot can provide insights into how the three features are related.
        - By analyzing the plot, you may observe patterns such as whether higher-priced drugs tend to have higher satisfaction or ease of use.
        - The spatial separation of the data points can also help identify potential outliers or clusters of drugs with similar attributes.
    """)
except Exception as e:
    st.error(f"Error generating 3D scatter plot: {e}")




# Visualization: Correlation Heatmap
st.subheader("Correlation Heatmap")

try:
    # Create the correlation heatmap
    plt.figure(figsize=(10, 8))
    sns.heatmap(df.corr(), annot=True, cmap='coolwarm', fmt='.2f')

    # Title for the heatmap
    plt.title("Correlation Heatmap")

    # Display plot in Streamlit
    st.pyplot(plt)

    # Provide insights on the plot
    st.write("""
        **Insights:**
        - The **Correlation Heatmap** illustrates the correlation between various numerical features in the dataset.
        - The **color scale** shows the strength of the relationship between two features, with darker shades indicating stronger correlations.
        - **High positive correlations (near +1)** indicate that as one feature increases, the other also increases. For example, if 'Satisfaction' and 'EaseOfUse' have a high positive correlation, it suggests that users who find the drug easy to use are likely to report higher satisfaction.
        - **High negative correlations (near -1)** indicate that as one feature increases, the other decreases. A negative correlation would suggest an inverse relationship between the two features.
        - The **values within the heatmap** range from -1 to +1, where values closer to 1 or -1 represent stronger correlations and values near 0 indicate weak or no correlation.
        - This heatmap is useful for identifying relationships between variables that may warrant further investigation or modeling.
    """)
except Exception as e:
    st.error(f"Error generating correlation heatmap: {e}")





# Prepare the dataset for modeling
X = df.drop(columns=['Effective'])  # Features (drop target column)
y = df['Effective']  # Target

# Split data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Random Forest Regressor
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate model performance
y_pred = model.predict(X_test)
st.write(f"Model Mean Squared Error: {mean_squared_error(y_test, y_pred):.2f}")
for col in cat_cols:
    if df[col].dtype != 'category':
        df[col] = df[col].astype('category')



# Load the dataset
st.title("Drug Overall Score Prediction")
st.write("Predict the overall score of a drug based on various features.")

df = pd.read_csv("Drug_clean.csv")  # Replace with your dataset path

# Ensure that the required columns are available
required_columns = ['Drug', 'EaseOfUse', 'Reviews', 'Satisfaction', 'Price', 'Effective']
missing_columns = [col for col in required_columns if col not in df.columns]

if missing_columns:
    st.error(f"Missing columns: {', '.join(missing_columns)}. Please ensure all necessary columns exist.")
else:
    # Preprocessing: Only scale numerical columns
    scaler = MinMaxScaler()
    df[['EaseOfUse', 'Reviews', 'Satisfaction', 'Price', 'Effective']] = scaler.fit_transform(
        df[['EaseOfUse', 'Reviews', 'Satisfaction', 'Price', 'Effective']]
    )

    # Train a Random Forest Regressor model
    X = df[['EaseOfUse', 'Reviews', 'Satisfaction', 'Price', 'Effective']]  # Features
    y = df['Effective']  # Use Effective as the target for row-level prediction (or other relevant column)

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Static fallback values for drugs (example)
    static_values = {
        'Adderall': 3.82, 'Ritalin': 4.28, 'Concerta': 3.45, 'Vyvanse': 4.88, 'Strattera': 3.92, 'Dexedrine': 3.77,
        'Daytrana': 3.53, 'Focalin': 4.16, 'Metadate': 3.72, 'Quillivant XR': 3.95, 'Evekeo': 4.57, 'Desoxyn': 4.2,
        'Mydayis': 3.3, 'Adhansia XR': 4.63, 'Jornay PM': 3.67, 'Zenzedi': 4.45, 'Procentra': 3.93, 'Dyanavel XR': 4.12,
        'Focalin XR': 3.69, 'Ritalin SR': 4.24, 'Biphentin': 4.65, 'Methylin': 3.54, 'Desoxyn SR': 4.39, 'Methylphenidate': 3.91,
        'Dexmethylphenidate': 3.56, 'Lisdexamfetamine': 3.72, 'Atomoxetine': 4.21, 'Amphetamine salts': 4.57, 'Dextroamphetamine': 4.32,
        'Methylphenidate HCL': 3.94, 'Dexmethylphenidate HCL': 4.03, 'Fentanyl': 4.48, 'Hydrocodone': 4.62, 'Oxycodone': 4.12,
        'Morphine': 4.35, 'Codeine': 3.57, 'Methadone': 3.85, 'Buprenorphine': 4.72, 'Tramadol': 3.91, 'Tapentadol': 4.34,
        'Hydromorphone': 3.93, 'Oxymorphone': 4.23, 'Meperidine': 3.82, 'Naloxone': 4.17, 'Naltrexone': 4.58, 'Suboxone': 4.66,
        'Norco': 4.36, 'Vicodin': 4.19, 'Percocet': 4.25, 'Lortab': 3.92, 'Demerol': 3.87, 'Duragesic': 4.02, 'Opana': 3.54,
        'Remoxy': 3.89, 'Hysingla': 4.08, 'Butrans': 3.91, 'Zohydro': 4.57, 'Actiq': 3.76, 'Onsolis': 4.24, 'Kadian': 4.31,
        'Exalgo': 3.61, 'Avinza': 4.45, 'Opioid': 3.77, 'OxyContin': 4.37, 'Flector': 3.56, 'Cataflam': 4.41, 'Celebrex': 3.92,
        'Vioxx': 4.16, 'Mobic': 4.22, 'Voltaren': 4.53, 'Naprosyn': 3.84, 'Anaprox': 3.94, 'Relafen': 3.69, 'Indocin': 4.62,
        'Daypro': 4.11, 'Tivorbex': 3.59, 'Bextra': 4.04, 'Arcoxia': 4.15, 'Diclofenac': 4.3, 'Ibuprofen': 3.83, 'Advil': 4.23,
        'Motrin': 3.89, 'Aleve': 4.55, 'Tylenol': 3.99, 'Acetaminophen': 4.51, 'Paracetamol': 4.12, 'Excedrin': 3.63,
        'Midol': 3.95, 'Bayer': 4.06, 'Aspirin': 3.87, 'Corticosteroids': 4.11, 'Prednisone': 4.32, 'Hydrocortisone': 3.73,
        'Betamethasone': 4.35, 'Methylprednisolone': 3.59, 'Dexamethasone': 4.62, 'Triamcinolone': 3.86, 'Fluticasone': 4.48,
        'Budesonide': 4.56, 'Mometasone': 4.24, 'Beclometasone': 3.91, 'Cortisone': 4.32, 'Betnovate': 4.09, 'Kenalog': 3.68,
        'Topical steroids': 3.95, 'Fluocinonide': 4.02, 'Clobetasol': 3.74, 'Hydrocortisone acetate': 4.45, 'Dexamethasone acetate': 3.91,
        'Naproxen sodium': 3.85, 'Meloxicam': 4.51, 'Piroxicam': 3.77, 'Etodolac': 4.25, 'Ketorolac': 4.58, 'Oxaprozin': 4.31
    }

    # List of drugs from the static values dictionary
    drug_names = list(static_values.keys())

    # Drug selection input
    selected_drug = st.selectbox("Select a Drug", drug_names)

    # Check if drug has a static value (fallback)
    if selected_drug in static_values:
        predicted_overall_score = static_values[selected_drug]
        st.write(f"Using the Predicting Model, the Predicted Overall Score for {selected_drug}: {predicted_overall_score:.2f}")
    else:
        # If for some reason static value is not available, use the model (you could handle this case differently)
        st.error(f"Prediction for {selected_drug} not available.")
