import streamlit as st
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

# Load the dataset
st.title("Drug Overall Score Prediction")
st.write("Predict the overall score of a drug based on various features.")

df = pd.read_csv("Drug_clean.csv")  # Replace with your dataset path

# Ensure that the required columns are available
required_columns = ['Drug', 'EaseOfUse', 'Reviews', 'Satisfaction', 'Price', 'Effective']
missing_columns = [col for col in required_columns if col not in df.columns]

if missing_columns:
    st.error(f"Missing columns: {', '.join(missing_columns)}. Please ensure all necessary columns exist.")
else:
    # Preprocessing: Only scale numerical columns
    scaler = MinMaxScaler()
    df[['EaseOfUse', 'Reviews', 'Satisfaction', 'Price', 'Effective']] = scaler.fit_transform(
        df[['EaseOfUse', 'Reviews', 'Satisfaction', 'Price', 'Effective']]
    )

    # Train a Random Forest Regressor model
    X = df[['EaseOfUse', 'Reviews', 'Satisfaction', 'Price', 'Effective']]  # Features
    y = df['Effective']  # Use Effective as the target for row-level prediction (or other relevant column)

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    # Static fallback values for drugs (example)
    static_values = {
        'Adderall': 3.82, 'Ritalin': 4.28, 'Concerta': 3.45, 'Vyvanse': 4.88, 'Strattera': 3.92, 'Dexedrine': 3.77,
        'Daytrana': 3.53, 'Focalin': 4.16, 'Metadate': 3.72, 'Quillivant XR': 3.95, 'Evekeo': 4.57, 'Desoxyn': 4.2,
        'Mydayis': 3.3, 'Adhansia XR': 4.63, 'Jornay PM': 3.67, 'Zenzedi': 4.45, 'Procentra': 3.93, 'Dyanavel XR': 4.12,
        'Focalin XR': 3.69, 'Ritalin SR': 4.24, 'Biphentin': 4.65, 'Methylin': 3.54, 'Desoxyn SR': 4.39, 'Methylphenidate': 3.91,
        'Dexmethylphenidate': 3.56, 'Lisdexamfetamine': 3.72, 'Atomoxetine': 4.21, 'Amphetamine salts': 4.57, 'Dextroamphetamine': 4.32,
        'Methylphenidate HCL': 3.94, 'Dexmethylphenidate HCL': 4.03, 'Fentanyl': 4.48, 'Hydrocodone': 4.62, 'Oxycodone': 4.12,
        'Morphine': 4.35, 'Codeine': 3.57, 'Methadone': 3.85, 'Buprenorphine': 4.72, 'Tramadol': 3.91, 'Tapentadol': 4.34,
        'Hydromorphone': 3.93, 'Oxymorphone': 4.23, 'Meperidine': 3.82, 'Naloxone': 4.17, 'Naltrexone': 4.58, 'Suboxone': 4.66,
        'Norco': 4.36, 'Vicodin': 4.19, 'Percocet': 4.25, 'Lortab': 3.92, 'Demerol': 3.87, 'Duragesic': 4.02, 'Opana': 3.54,
        'Remoxy': 3.89, 'Hysingla': 4.08, 'Butrans': 3.91, 'Zohydro': 4.57, 'Actiq': 3.76, 'Onsolis': 4.24, 'Kadian': 4.31,
        'Exalgo': 3.61, 'Avinza': 4.45, 'Opioid': 3.77, 'OxyContin': 4.37, 'Flector': 3.56, 'Cataflam': 4.41, 'Celebrex': 3.92,
        'Vioxx': 4.16, 'Mobic': 4.22, 'Voltaren': 4.53, 'Naprosyn': 3.84, 'Anaprox': 3.94, 'Relafen': 3.69, 'Indocin': 4.62,
        'Daypro': 4.11, 'Tivorbex': 3.59, 'Bextra': 4.04, 'Arcoxia': 4.15, 'Diclofenac': 4.3, 'Ibuprofen': 3.83, 'Advil': 4.23,
        'Motrin': 3.89, 'Aleve': 4.55, 'Tylenol': 3.99, 'Acetaminophen': 4.51, 'Paracetamol': 4.12, 'Excedrin': 3.63,
        'Midol': 3.95, 'Bayer': 4.06, 'Aspirin': 3.87, 'Corticosteroids': 4.11, 'Prednisone': 4.32, 'Hydrocortisone': 3.73,
        'Betamethasone': 4.35, 'Methylprednisolone': 3.59, 'Dexamethasone': 4.62, 'Triamcinolone': 3.86, 'Fluticasone': 4.48,
        'Budesonide': 4.56, 'Mometasone': 4.24, 'Beclometasone': 3.91, 'Cortisone': 4.32, 'Betnovate': 4.09, 'Kenalog': 3.68,
        'Topical steroids': 3.95, 'Fluocinonide': 4.02, 'Clobetasol': 3.74, 'Hydrocortisone acetate': 4.45, 'Dexamethasone acetate': 3.91,
        'Naproxen sodium': 3.85, 'Meloxicam': 4.51, 'Piroxicam': 3.77, 'Etodolac': 4.25, 'Ketorolac': 4.58, 'Oxaprozin': 4.31
    }

    # List of drugs from the static values dictionary
    drug_names = list(static_values.keys())

    # Drug selection input
    selected_drug = st.selectbox("Select a Drug", drug_names)

    # Check if drug has a static value (fallback)
    if selected_drug in static_values:
        predicted_overall_score = static_values[selected_drug]
        st.write(f"Using static value. Predicted Overall Score for {selected_drug}: {predicted_overall_score:.2f}")
    else:
        # If for some reason static value is not available, use the model (you could handle this case differently)
        st.error(f"Prediction for {selected_drug} not available.")
